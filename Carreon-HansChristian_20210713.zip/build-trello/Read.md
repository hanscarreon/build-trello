copy whole folder in localhost and
run in localhost
foldername = build-trello
localhost/'foldername'/?views=board
localhost/'foldername'/?views=tile